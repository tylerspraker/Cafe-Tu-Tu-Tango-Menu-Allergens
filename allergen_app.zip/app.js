
function searchAllergens() {
  const input = document.getElementById('search').value.toLowerCase();
  const safe = menuData.filter(i => !i.allergens.map(a=>a.toLowerCase()).includes(input));
  const unsafe = menuData.filter(i => i.allergens.map(a=>a.toLowerCase()).includes(input));

  document.getElementById('results').innerHTML = `
    <h2>Unsafe Items</h2>
    <ul>${unsafe.map(i=>`<li>${i.item}</li>`).join('')}</ul>
    <h2>Safe Items</h2>
    <ul>${safe.map(i=>`<li>${i.item}</li>`).join('')}</ul>
  `;
}
