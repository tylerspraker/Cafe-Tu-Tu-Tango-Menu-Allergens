const menuData = [
  {
    "item": "Black Bean Hummus",
    "allergens": [
      "Wheat",
      "Dairy",
      "Peanuts",
      "Sesame",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Tzatziki",
    "allergens": [
      "Wheat",
      "Dairy",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Chilled Mediterranean Spinach Dip",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Tree Nuts",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Street Corn",
    "allergens": [
      "Soy/Soybeans",
      "Dairy",
      "Eggs",
      "Allium",
      "Nightshade"
    ]
  },
  {
    "item": "Crispy Brussels Sprouts",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Shellfish",
      "Fish",
      "Sesame",
      "Allium",
      "Gluten"
    ]
  },
  {
    "item": "Jamon Serrano Croquetas",
    "allergens": [
      "Wheat",
      "Dairy",
      "Shellfish",
      "Fish",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Brick Oven Roasted Sweet Potatoes",
    "allergens": [
      "Dairy",
      "Tree Nuts",
      "Allium",
      "Nightshade"
    ]
  },
  {
    "item": "Chilled Chili Udon Noodles",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Sesame",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Marinated Cucumbers",
    "allergens": [
      "Soy/Soybeans",
      "Sesame",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Mandarin Orange Salad",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Peanuts",
      "Sesame",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Cuban Sliders",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Pibli Style Cauliflower Tacos",
    "allergens": [
      "Dairy",
      "Shellfish",
      "Fish",
      "Allium",
      "Nightshade"
    ]
  },
  {
    "item": "Baja Fish Tacos",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Shellfish",
      "Fish",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Guajillo-Roasted Mushroom Tacos",
    "allergens": [
      "Soy/Soybeans",
      "Dairy",
      "Allium",
      "Nightshade"
    ]
  },
  {
    "item": "Chicken Chorizo Sliders",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Duck Confit Sliders",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Fish",
      "Eggs",
      "Sesame",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Dynamite Shrimp",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Shellfish",
      "Fish",
      "Eggs",
      "Sesame",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Butter Chicken Tikka Masala",
    "allergens": [
      "Dairy",
      "Allium",
      "Nightshade"
    ]
  },
  {
    "item": "Garlic-Maple Chicken Wings",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Shellfish",
      "Fish",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Smoked Thai Spare Ribs",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Fish",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Jerk Chicken Skewers",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Sesame Steak Skewers",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Eggs",
      "Sesame",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Spiced Alligator Bites",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Shellfish",
      "Fish",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Cajun Chicken Egg Rolls",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Shellfish",
      "Fish",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Duck Confit Salad",
    "allergens": [
      "Wheat",
      "Dairy",
      "Tree Nuts",
      "Fish",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Pepperoni Pizza",
    "allergens": [
      "Wheat",
      "Dairy",
      "Allium",
      "Gluten"
    ]
  },
  {
    "item": "Cubano Pizza",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Street Corn Pizza",
    "allergens": [
      "Wheat",
      "Dairy",
      "Eggs",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Cajun Chicken Pizza",
    "allergens": [
      "Wheat",
      "Soy/Soybeans",
      "Dairy",
      "Fish",
      "Eggs",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Sausage & Peppers Pizza",
    "allergens": [
      "Wheat",
      "Dairy",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Tex Mex Taco Pizza",
    "allergens": [
      "Wheat",
      "Dairy",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Mushroom Pizza",
    "allergens": [
      "Wheat",
      "Dairy",
      "Allium",
      "Gluten",
      "Nightshade"
    ]
  },
  {
    "item": "Triple Chocolate Cake Pops",
    "allergens": [
      "Wheat",
      "Dairy",
      "Eggs",
      "Gluten"
    ]
  },
  {
    "item": "Warm Guava Bread Pudding",
    "allergens": [
      "Wheat",
      "Dairy",
      "Tree Nuts",
      "Eggs",
      "Gluten"
    ]
  },
  {
    "item": "Coconut Mango Parfait",
    "allergens": [
      "Dairy",
      "Tree Nuts"
    ]
  },
  {
    "item": "Flourless Chocolate Cake",
    "allergens": [
      "Dairy",
      "Tree Nuts",
      "Eggs",
      "Nightshade"
    ]
  },
  {
    "item": "KEY",
    "allergens": []
  },
  {
    "item": "Food can not be modified",
    "allergens": [
      "Wheat"
    ]
  },
  {
    "item": "Food can be modified",
    "allergens": [
      "Wheat"
    ]
  },
  {
    "item": "Cross-Contamination Warning",
    "allergens": [
      "Wheat"
    ]
  }
];